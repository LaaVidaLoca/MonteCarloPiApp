package holder;

public class EagerHolder extends Holder {
    public static final EagerHolder INSTANCE = new EagerHolder();
    private EagerHolder() {}
}
